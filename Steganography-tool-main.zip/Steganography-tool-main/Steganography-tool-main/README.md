🕵️‍♂️ Steganography Tool

A Python-based tool to hide and retrieve secret messages in images using steganography techniques.

📚 Project Overview

This project allows you to securely embed secret messages into images and later decode them. It provides a simple command-line interface to perform encoding and decoding operations with sample data.

⚡ Features

Encode secret messages into images

Decode hidden messages from images

Simple command-line interface

Well-structured code and sample data

🚀 Installation

Clone the repository:

git clone https://github.com/your-username/steganography-tool.git
cd steganography-tool


Install dependencies:

pip install -r steganography-tool/requirements.txt

🎯 Usage
Encode a message:
python steganography-tool/src/stego_app.py --encode --input input_image.png --message "Your secret message" --output output_image.png

Decode a message:
python steganography-tool/src/stego_app.py --decode --input output_image.png

📂 Sample Data

Sample images and decoded messages are available in the steganography-tool/data/ folder for testing.

📄 Documentation

The detailed project report is available in the docs/Steganography Report.pdf.

⚠️ Note

Ensure Python 3.x is installed and the dependencies from requirements.txt are satisfied before running the tool.

📜 License

This project is licensed under the MIT License.