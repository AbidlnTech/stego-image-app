import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image

# ---------------- Functions ---------------- #
def load_image():
    global img, img_path
    img_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.bmp")])
    if img_path:
        img = Image.open(img_path).convert("RGB")
        lbl_image.config(text=f"Loaded: {img_path.split('/')[-1]}")
        txt_message.delete(1.0, tk.END)

def encode_message():
    if not img_path:
        messagebox.showerror("Error", "No image loaded")
        return
    message = txt_message.get(1.0, tk.END).strip()
    if not message:
        messagebox.showerror("Error", "Enter a message to encode")
        return
    binary_message = ''.join([format(ord(c), '08b') for c in message]) + '1111111111111110'
    pixels = list(img.getdata())
    new_pixels = []
    i = 0
    for pixel in pixels:
        r, g, b = pixel
        if i < len(binary_message):
            r = (r & ~1) | int(binary_message[i])
            i += 1
        if i < len(binary_message):
            g = (g & ~1) | int(binary_message[i])
            i += 1
        if i < len(binary_message):
            b = (b & ~1) | int(binary_message[i])
            i += 1
        new_pixels.append((r, g, b))
    new_img = Image.new(img.mode, img.size)
    new_img.putdata(new_pixels)
    save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Image", "*.png")])
    if save_path:
        new_img.save(save_path)
        messagebox.showinfo("Success", f"Message encoded and saved as {save_path}")

def decode_message():
    if not img_path:
        messagebox.showerror("Error", "No image loaded")
        return
    pixels = list(img.getdata())
    binary_message = ''
    for r, g, b in pixels:
        binary_message += str(r & 1)
        binary_message += str(g & 1)
        binary_message += str(b & 1)
    all_bytes = [binary_message[i:i+8] for i in range(0, len(binary_message), 8)]
    message = ''
    for byte in all_bytes:
        if byte == '11111111':
            break
        message += chr(int(byte, 2))
    txt_message.delete(1.0, tk.END)
    txt_message.insert(tk.END, message)

# ---------------- GUI ---------------- #
root = tk.Tk()
root.title("Steganography Tool")
root.geometry("500x400")
root.config(bg="#2C3E50")

lbl_title = tk.Label(root, text="Steganography Tool", font=("Helvetica", 18, "bold"), fg="white", bg="#2C3E50")
lbl_title.pack(pady=10)

btn_load = tk.Button(root, text="Load Image", width=20, command=load_image, bg="#3498DB", fg="white")
btn_load.pack(pady=5)

lbl_image = tk.Label(root, text="No image loaded", bg="#2C3E50", fg="white")
lbl_image.pack(pady=5)

txt_message = tk.Text(root, height=5, width=50)
txt_message.pack(pady=10)

btn_encode = tk.Button(root, text="Encode Message", width=20, command=encode_message, bg="#2ECC71", fg="white")
btn_encode.pack(pady=5)

btn_decode = tk.Button(root, text="Decode Message", width=20, command=decode_message, bg="#E74C3C", fg="white")
btn_decode.pack(pady=5)

root.mainloop()
